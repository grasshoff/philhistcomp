from typing import Dict, Any, List, Union, Optional, Callable
from enum import Enum
from pydantic import validator, BaseModel, Field, Schema
from pydantic import StrictStr, StrictInt, StrictFloat, StrictBool
from fastapi.security.http import HTTPAuthorizationCredentials


# Task submodels


class ViewId(str, Enum):
    text = "text"
    classification = "classification"
    ner = "ner"
    ner_manual = "ner_manual"
    pos = "pos"
    pos_manual = "pos_manual"
    dep = "dep"
    image = "image"
    image_manual = "image_manual"
    html = "html"
    choice = "choice"
    diff = "diff"
    compare = "compare"
    review = "review"
    text_input = "text_input"
    blocks = "blocks"
    audio = "audio"
    audio_manual = "audio_manual"
    relations = "relations"


class Answer(str, Enum):
    accept: str = "accept"
    reject: str = "reject"
    ignore: str = "ignore"


class ImageManualType(str, Enum):
    rect: str = "rect"
    polygon: str = "polygon"
    freehand: str = "freehand"


class Token(BaseModel):
    start: StrictInt
    end: StrictInt
    id: StrictInt
    disabled: StrictBool = False


class TextSpan(BaseModel):
    start: StrictInt
    end: StrictInt
    label: Optional[StrictStr] = None


class TextSpanLabel(BaseModel):
    start: StrictInt
    end: StrictInt
    label: StrictStr


class TextManualSpan(TextSpan):
    token_start: StrictInt
    token_end: StrictInt


class ImageSpan(BaseModel):
    id: Optional[Union[int, str]] = None
    type: Optional[ImageManualType] = None
    label: Optional[StrictStr] = None
    points: Optional[List[List[Union[float, int]]]] = None
    width: Optional[Union[float, int]] = None
    height: Optional[Union[float, int]] = None
    x: Optional[Union[float, int]] = None
    y: Optional[Union[float, int]] = None
    center: Optional[List[Union[float, int]]] = None
    color: Optional[str] = None


class AudioSpan(BaseModel):
    start: Union[StrictInt, StrictFloat]
    end: Union[StrictInt, StrictFloat]
    label: StrictStr
    color: Optional[StrictStr] = None
    id: Optional[StrictStr] = None


AnySpan = Union[TextSpan, TextManualSpan, ImageSpan]


class Relation(BaseModel):
    head: StrictInt
    child: StrictInt
    label: str
    color: Optional[str] = None


class ChoiceOption(BaseModel):
    id: Union[str, int]
    text: Optional[str] = None
    image: Optional[str] = None
    html: Optional[str] = None
    spans: List[AnySpan] = None
    style: Dict[str, Any] = None


class ReviewVersion(BaseModel):
    sessions: List[Union[str, None]]
    default = False
    text: StrictStr = None
    image: StrictStr = None
    html: StrictStr = None
    spans: List[AnySpan] = None
    options: List[ChoiceOption] = None
    accept: List[Union[str, int]] = None
    answer: Answer


# Task models


class TaskModel(BaseModel):
    # These are properties that our task-specific models inherit from
    # Field aliases so underscore attributes aren't excluded from JSON schema
    input_hash: StrictInt = Field(..., alias="_input_hash")
    task_hash: StrictInt = Field(..., alias="_task_hash")
    view_id: Optional[ViewId] = Field(None, alias="_view_id")
    session_id: Optional[StrictStr] = Field(None, alias="_session_id")
    meta: Dict[str, Any] = {}


class TextTask(TaskModel):
    text: StrictStr


class HtmlTask(TaskModel):
    html: Optional[StrictStr] = None
    text: Optional[StrictStr] = None


class ClassificationTask(TaskModel):
    text: Optional[StrictStr] = None
    image: Optional[StrictStr] = None
    html: Optional[StrictStr] = None
    label: Optional[StrictStr] = None
    spans: Optional[List[AnySpan]] = None
    audio_spans: Optional[List[AudioSpan]] = None


class SpansTask(TaskModel):
    text: StrictStr
    spans: List[TextSpan]


class SpansManualTask(TaskModel):
    text: StrictStr
    spans: List[TextManualSpan] = []
    tokens: List[Token]


class RelationsTask(TaskModel):
    text: StrictStr
    spans: Optional[List[TextManualSpan]] = []
    tokens: List[Token]
    relations: Optional[List[Relation]] = []


class ImageTask(TaskModel):
    image: StrictStr
    width: Optional[Union[int, float]] = None
    height: Optional[Union[int, float]] = None
    spans: Optional[List[ImageSpan]] = None


class DepTask(TaskModel):
    text: StrictStr
    arcs: List[Relation]
    relations: List[Relation] = None
    tokens: List[Token]


class ChoiceTask(TaskModel):
    text: Optional[StrictStr] = None
    image: Optional[StrictStr] = None
    html: Optional[StrictStr] = None
    options: Optional[List[ChoiceOption]] = None
    accept: List[Union[str, int]] = []


class CompareTask(TaskModel):
    id: Union[str, int]
    input: Dict[str, Any] = None
    accept: Dict[str, Any]
    reject: Dict[str, Any]
    mapping: Dict[str, str]


class DiffTask(TaskModel):
    text: StrictStr = None
    added: StrictStr = None
    removed: StrictStr = None
    input: Dict[str, Any] = None
    # This would clash with choice:
    # accept: Dict[str, Any]
    reject: Dict[str, Any]


class ReviewTask(TaskModel):
    versions: List[ReviewVersion]
    view_id: ViewId


class TextInputTask(TaskModel):
    field_id: Optional[str] = None
    field_label: Optional[StrictStr] = None
    field_placeholder: Optional[StrictStr] = None
    field_rows: Optional[int] = None
    field_autofocus: Optional[bool] = False


class BlocksTask(TaskModel):
    pass


class AudioTask(TaskModel):
    # TODO: custom validation
    audio: Optional[StrictStr]
    video: Optional[StrictStr]
    audio_spans: Optional[List[AudioSpan]] = None


# Training examples models


class NerExample(TaskModel):
    text: StrictStr
    spans: Optional[List[TextSpanLabel]] = []
    answer: Answer


class TextcatExample(TaskModel):
    text: StrictStr
    options: List[ChoiceOption] = None
    accept: List[Union[str, int]] = []
    label: Optional[StrictStr] = None
    answer: Answer

    # See: https://github.com/samuelcolvin/pydantic/issues/506
    @validator("label", pre=True, always=True, whole=True)
    def validate_label(cls, v, values):
        if not v and "options" not in values or "accept" not in values:
            print(values)
            raise ValueError("expected 'label' OR 'options' and 'accept'")
        return v


class PosExample(TaskModel):
    text: StrictStr
    spans: List[TextSpanLabel]
    answer: Answer


class DepExample(DepTask):
    text: StrictStr
    arcs: Optional[List[Relation]]
    relations: Optional[List[Relation]]
    answer: Answer


# Prodigy config submodels


class ConfigTheme(str, Enum):
    basic: str = "basic"
    eighties: str = "eighties"
    spacy: str = "spacy"
    brutalist: str = "brutalist"


class ConfigDbSettings(BaseModel):
    sqlite: Dict[str, str] = {}
    mysql: Dict[str, Any] = {}
    postgresql: Dict[str, Any] = {}


class ConfigDiffStyle(str, Enum):
    words: str = "words"
    chars: str = "chars"
    sentences: str = "sentences"


class ConfigWritingDir(str, Enum):
    ltr: str = "ltr"
    rtl: str = "rtl"


class ConfigNerManualLabelStyle(str, Enum):
    list: str = "list"
    dropdown: str = "dropdown"


class ConfigChoiceStyle(str, Enum):
    single: str = "single"
    multiple: str = "multiple"


class ConfigBlock(BaseModel):
    view_id: ViewId = "text"


class ConfigExcludeBy(str, Enum):
    task: str = "task"
    input: str = "input"


class ConfigButton(str, Enum):
    accept: str = "accept"
    reject: str = "reject"
    ignore: str = "ignore"
    undo: str = "undo"


# Prodigy config


class Config(BaseModel):
    # fmt: off
    buttons: List[ConfigButton] = ["accept", "reject", "ignore", "undo"]
    theme: ConfigTheme = "basic"
    custom_theme: Dict[str, Any] = {}
    batch_size: Optional[int] = 10
    history_size: Optional[int] = None
    port: StrictInt = 8080
    host: StrictStr = "localhost"
    cors: StrictBool = True
    db: StrictStr = "sqlite"
    db_settings: ConfigDbSettings = {}
    api_keys: Dict[str, Any] = {}
    _validate: StrictBool = Field(True, alias="validate")  # shadows BaseModel attribute
    auto_create: StrictBool = True
    auto_exclude_current: StrictBool = True
    instant_submit: StrictBool = False
    feed_overlap: StrictBool = True
    show_stats: StrictBool = False
    hide_meta: StrictBool = False
    show_flag: StrictBool = False
    instructions: Union[StrictStr, StrictBool, None] = None
    swipe: StrictBool = False
    split_sents_threshold: Union[int, StrictBool, None] = None
    diff_style: ConfigDiffStyle = "words"
    html_template: Union[StrictStr, StrictBool, None] = None
    javascript: Optional[StrictStr] = None
    global_css: Optional[StrictStr] = None
    card_css: Optional[Union[Dict[str, Any], StrictBool]] = None
    writing_dir: ConfigWritingDir = "ltr"
    hide_true_newline_tokens: StrictBool = False
    honor_token_whitespace: StrictBool = True
    ner_manual_require_click: StrictBool = False
    ner_manual_label_style: ConfigNerManualLabelStyle = "list"
    choice_style: ConfigChoiceStyle = "single"
    choice_auto_accept: StrictBool = False
    darken_image: Union[StrictFloat, StrictInt] = 0
    show_bounding_box_center: StrictBool = False
    preview_bounding_boxes: StrictBool = False
    shade_bounding_boxes: StrictBool = False
    user_config: Dict[str, Any] = {}
    label: Optional[StrictStr] = None
    labels: List[StrictStr] = []
    blocks: List[ConfigBlock] = []
    exclude_by: ConfigExcludeBy = "task"
    keymap: Optional[Dict[str, List[str]]] = {}
    keymap_by_label: Optional[Dict[str, str]] = {}
    show_audio_cursor: Optional[StrictBool] = True
    show_audio_cursor_time: Optional[StrictBool] = True
    show_audio_timeline: Optional[StrictBool] = False
    show_audio_minimap: Optional[StrictBool] = True
    audio_bar_width: Optional[StrictInt] = 3
    audio_bar_height: Optional[StrictInt] = 2
    audio_bar_gap: Optional[StrictInt] = 2
    audio_bar_radius: Optional[StrictInt] = 2
    audio_max_zoom: Optional[StrictInt] = 5000
    audio_autoplay: Optional[StrictBool] = False
    audio_loop: Optional[StrictBool] = False
    audio_rate: Optional[Union[StrictInt, StrictFloat]] = 1.0
    wrap_relations: Optional[StrictBool] = False
    show_relations_labels: Optional[StrictBool] = True
    hide_relations_arrow: Optional[StrictBool] = False
    relations_span_labels: Optional[List[StrictStr]] = []
    image_manual_legacy: Optional[StrictBool] = False
    image_manual_modes: Optional[List[ImageManualType]] = ["rect", "polygon", "freehand"]
    image_manual_stroke_width: Optional[StrictInt] = 4
    image_manual_font_size: Optional[StrictInt] = 16
    image_manual_from_center: Optional[StrictBool] = False
    image_manual_show_labels: Optional[StrictBool] = True
    # fmt: on

    @validator(
        "instructions",
        "html_template",
        "split_sents_threshold",
        "card_css",
        pre=True,
        always=True,
        whole=True,
    )
    def ensure_false(cls, v):
        # Backwards-compatible hack to support False-only boolean values
        if isinstance(v, bool) and v is not False:
            raise ValueError("expected value or false, not true")
        return v


# Recipe components


class RecipeComponents(BaseModel):
    dataset: Union[str, bool]
    view_id: ViewId
    stream: Any  # TODO: how to type Iterable in pydantic?
    update: Optional[Callable]
    db: Optional[Any] = True
    progress: Optional[Callable] = None
    on_load: Optional[Callable] = None
    on_exit: Optional[Callable] = None
    before_db: Optional[Callable] = None
    validate_answer: Optional[Callable] = None
    get_session_id: Optional[Callable] = None
    exclude: Optional[List[str]] = None
    config: Optional[Config] = {}

    class Config:
        extra = "forbid"

    @validator("stream", pre=True, always=True, whole=True)
    def validate_stream(cls, v):
        if not hasattr(v, "__iter__"):
            raise ValueError(f"expected iterable, not {type(v)}")

    @validator(
        "dataset",
        "update",
        "progress",
        "on_load",
        "on_exit",
        "exclude",
        pre=True,
        always=True,
        whole=True,
    )
    def ensure_false(cls, v):
        # Support False-only boolean values, just in case
        if isinstance(v, bool) and v is not False:
            raise ValueError("expected value or false, not true")
        return v


# REST API


class SessionID(BaseModel):
    session_id: str
    aliases: List[str] = []


class JWTPayload(BaseModel):
    """JSON Web Token payload"""

    exp: int = Schema(..., description="Token expiration date in UTC milliseconds")
    aud: str = Schema(..., description="The audience that the token is intended for")
    iss: str = Schema(..., description="The issuer of the auth token.")


class APIVersionResponse(BaseModel):
    name: str
    description: str
    author: str
    author_email: str
    url: str
    version: str
    license: str


class APIProjectResponse(BaseModel):
    pass


class APISessionQuestionsRequest(BaseModel):
    session_id: Optional[str]
    excludes: Optional[List[int]]


class APIQuestionsResponse(BaseModel):
    tasks: List
    total: int
    progress: Optional[float]
    session_id: str


class APIAnswersRequest(BaseModel):
    answers: List
    session_id: Optional[str] = None


class APIAnswersResponse(BaseModel):
    progress: Optional[float]


class APIAnswerValidateRequest(BaseModel):
    answer: Dict


class APIAnswerValidateResponse(BaseModel):
    ok: bool
    message: Optional[str]


class APISessionAliasesRequest(BaseModel):
    session_id: str
    aliases: List


class JWTAuthorizationCredentials(HTTPAuthorizationCredentials):
    credentials: str = Schema(..., description="The source JWT token string")
    scheme: str = Schema("bearer", description="the HTTP authorization scheme")
    payload: JWTPayload = Schema(..., description="JSON payload extracted from token")
