import random
import datetime
import requests

from ..util import msg, log, registry


deprecation_msg = """
As of v1.9 live APIs are deprecated. API loaders are difficult to
maintain and can be quite unpredictable due to rate limits etc. For a more
reliable experience, we recommend downloading and converting the data from the
API and then using the converted static data.
"""


def make_api_request(url, params=dict(), headers=dict()):
    """Make a GET request via requests. Mostly used in built-in loaders. Will
    use `raise_for_status` to raise an error if request was not successful.

    url (unicode): The URL to request.
    params (dict): Optional parameters to add as the params keyword argument.
    headers (dict): Optional headers to add as the headers keyword argument.
    RETURNS (json): The response converted to JSON.
    """
    response = requests.get(url, params=params, headers=headers)
    response.raise_for_status()
    return response.json()


class NewYorkTimes(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in headlines, excerpts, images & meta from the New York
    Times API. Available settings: query, key, content_type, n_results
    """

    source_name = "The New York Times"
    url = "https://api.nytimes.com/svc/search/v2/articlesearch.json"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.content_type = settings.get("content_type", "headline")
        self.params = {"q": settings.get("query", ""), "api-key": settings.get("key")}
        self.page = 0
        self.total_results = 0

    def __iter__(self):
        while True:
            self.params["page"] = self.page
            response = make_api_request(self.url, self.params)
            response = response["response"]
            self.total_results = response["meta"]["hits"]
            stream = response["docs"]
            for item in stream:
                task = self.get_task(item)
                if task is not None:
                    yield task
            self.page += 1

    def __len__(self):
        return self.total_results

    def get_task(self, item):
        meta = {"source": self.source_name}
        if self.content_type == "image":
            image = self.get_image(item["multimedia"])
            if image is None:
                return None
            meta["headline"] = item["headline"]["main"]
            return {
                "image": f"http://www.nytimes.com/{image['url']}",
                "meta": meta,
                "text": item["headline"]["main"],
            }
        if self.content_type == "snippet":
            text = item["snippet"]
        elif self.content_type == "lead":
            text = item["lead_paragraph"]
        else:
            text = item["headline"]["main"]
        if text is None:
            return None
        return {"text": text, "meta": meta}

    def get_image(self, images):
        for img in images:
            if img["type"] == "image" and img["subtype"] == "xlarge":
                return img
        return None


class Guardian(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in headlines and meta data from The Guardian API.
    Available settings: query, key, page_size, section, lang
    """

    source_name = "The Guardian"
    url = "http://content.guardianapis.com/search"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.params = {
            "q": settings.get("query", ""),
            "api-key": settings.get("key"),
            "page-size": settings.get("page_size", 50),
        }
        for setting in ["section", "lang"]:
            if setting in settings:
                self.params[setting] = settings[setting]
        self.page = 1
        self.total_results = 0

    def __iter__(self):
        while True:
            self.params["page"] = self.page
            response = make_api_request(self.url, self.params)
            response = response["response"]
            self.total_results = response["total"]
            stream = response["results"]
            for item in stream:
                task = self.get_task(item)
                if task is not None:
                    yield task
            self.page += 1

    def __len__(self):
        return self.total_results

    def get_task(self, item):
        meta = {"source": self.source_name, "section": item["sectionName"]}
        return {"text": item["webTitle"], "meta": meta}


class Zeit(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in headlines and meta data from the Die Zeit API (German).
    Available settings: query, key, page_size
    """

    source_name = "Die Zeit"
    url = "http://api.zeit.de/content"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.limit = settings.get("page_size", 100)
        self.content_type = settings.get("content_type", "title")
        self.params = {
            "q": settings.get("query", ""),
            "api_key": settings.get("key"),
            "limit": self.limit,
        }
        self.offset = 0
        self.total_results = 0

    def __iter__(self):
        while True:
            self.params["offset"] = self.offset
            response = make_api_request(self.url, self.params)
            self.total_results = response["found"]
            stream = response["matches"]
            for item in stream:
                task = self.get_task(item)
                if task is not None:
                    yield task
            self.offset += self.limit

    def __len__(self):
        return self.total_results

    def get_task(self, item):
        meta = {"source": self.source_name}
        if self.content_type == "snippet":
            text = item["snippet"]
        elif self.content_type == "teaser":
            text = item["teaser_text"]
        else:
            text = f"{item['title']} - {item.get('subtitle', '')}"
        return {"text": text, "meta": meta}


class NewsAPI(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in headlines and meta data from News API.
    Available settings: sources, shuffle, key, sort_by, content_type
    """

    source_name = "News API"
    url = "https://newsapi.org/v2/everything"
    source_url = "https://newsapi.org/v2/sources"
    default_sources = [
        "bbc-news",
        "al-jazeera-english",
        "associated-press",
        "bloomberg",
        "cnn",
        "independent",
        "recode",
        "reuters",
        "techcrunch",
        "the-guardian-au",
        "the-guardian-uk",
        "the-new-york-times",
        "the-verge",
        "the-washington-post",
    ]

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        source_params = {
            "apiKey": settings.get("key", ""),
            "language": settings.get("lang", "en"),
        }
        source_meta = make_api_request(self.source_url, source_params)
        self.source_meta = {s["id"]: s["name"] for s in source_meta["sources"]}
        self.sources = settings.get("sources", self.default_sources)
        if isinstance(self.sources, str):
            self.sources = self.sources.split(",")
        if settings.get("shuffle", True) is True:
            random.shuffle(self.sources)
        self.content_type = settings.get("content_type", "description")
        self.params = {
            "apiKey": settings.get("key"),
            "sortBy": settings.get("sort_by", "relevancy"),
            "language": settings.get("language", "en"),
            "pageSize": 100,
        }
        if "query" in settings:
            self.params["q"] = settings["query"]
        self.source_idx = 0
        self.total_results = len(self.sources) * 10

    def __iter__(self):
        while len(self.sources) > self.source_idx:
            self.params["source"] = self.sources[self.source_idx]
            response = make_api_request(self.url, self.params)
            stream = response["articles"]
            for item in stream:
                task = self.get_task(item, self.sources[self.source_idx])
                if task is not None:
                    yield task
            self.source_idx += 1

    def __len__(self):
        return self.total_results

    def get_task(self, item, source):
        meta = {"source": self.source_meta.get(source, source), "via": self.source_name}
        if self.content_type == "image":
            return {
                "image": item["urlToImage"],
                "meta": meta,
                "text": item[self.content_type],
            }
        if item.get(self.content_type) is None:
            return None
        task = {"text": item[self.content_type], "meta": meta}
        return task


class Twitter(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in tweets posts for a specific search query.
    Available settings: query, content_type, sort_by, date_limit, lang,
    replies, retweets, urls, hashtags, media.
    """

    source_name = "Twitter"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        try:
            import TwitterSearch
        except ImportError:
            raise ImportError("Please install TwitterSearch: pip install twittersearch")
        self.replies = settings.get("replies", True)
        self.retweets = settings.get("retweets", True)
        self.urls = settings.get("urls", True)
        self.hashtags = settings.get("hashtags", True)
        self.media = settings.get("media", True)
        query = settings.get("query", "")
        keys = settings.get("key")
        twitter = TwitterSearch.TwitterSearch(**keys)
        if settings.get("content_type") == "user":
            order = TwitterSearch.TwitterUserOrder(query)
            order.set_include_rts(self.retweets)
            order.set_exclude_replies(not self.replies)
        else:
            order = TwitterSearch.TwitterSearchOrder()
            order.set_include_entities(True)
            order.set_result_type(settings.get("sort_by", "mixed"))
            if settings.get("date_limit") is not None:
                order.set_until(self.get_date(settings("date_limit")))
            order.set_keywords(query.split(" "))
            order.set_language(settings.get("lang", "en"))
        self.stream = twitter.search_tweets_iterable(order)

    def __iter__(self):
        for item in self.stream:
            if "text" in item:
                is_reply = item["in_reply_to_user_id"] is not None
                is_retweet = item["text"].startswith("RT @")
                has_urls = len(item["entities"]["urls"]) > 0
                has_hashtags = len(item["entities"]["hashtags"]) > 0
                has_media = len(item["entities"].get("media", [])) > 0
                if (
                    (self.replies is False and is_reply)
                    or (self.retweets is False and is_retweet)
                    or (self.urls is False and has_urls)
                    or (self.hashtags is False and has_hashtags)
                    or (self.media is False and has_media)
                ):
                    continue
                yield self.get_task(item)

    def __len__(self):
        return self.stream.get_amount_of_tweets()

    def get_date(date):
        if isinstance(date, str):
            year, month, day = date.split("-")
            date = datetime.date(year=int(year), month=int(month), day=int(day))
        return date

    def get_task(self, item):
        date = item["created_at"].split(" ")
        meta = {
            "source": self.source_name,
            "user": f"@{item['user']['screen_name']}",
            "date": " ".join([date[1], date[2], date[5]]),
        }
        return {"text": item["text"], "meta": meta}


class Tumblr(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in Tumblr posts for a specific tag.
    Available settings: query, content_type, page_size
    """

    source_name = "Tumblr"
    url = "https://api.tumblr.com/v2/tagged"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.query = settings.get("query", "")
        self.content_type = settings.get("content_type", "photo")
        self.limit = settings.get("page_size", 50)
        self.params = {
            "tag": self.query,
            "filter": "text",
            "api_key": settings.get("key"),
            "limit": self.limit,
        }
        self.total_results = self.limit
        self.seen_tags = {self.query}
        self.timestamp = 0

    def __iter__(self):
        while True:
            log(f"LOADER: Making API request to {self.url}", self.params)
            self.params["before"] = self.timestamp
            response = make_api_request(self.url, self.params)
            self.total_results += self.limit
            stream = response["response"]
            for item in stream:
                self.timestamp = item["timestamp"]
                if self.content_type == "tags":
                    for tag in item["tags"]:
                        if tag not in self.seen_tags:
                            yield self.get_tag_task(tag)
                elif item["type"] == "photo":
                    yield self.get_image_task(item)

    def __len__(self):
        return self.total_results

    def get_tag_task(self, text):
        self.seen_tags.add(text)
        meta = {"source": self.source_name}
        return {"text": text, "meta": meta}

    def get_image_task(self, item):
        meta = {"source": self.source_name}
        meta["url"] = item["short_url"]
        photo = item["photos"][0]
        task = {
            "image": photo["original_size"]["url"],
            "width": photo["original_size"]["width"],
            "height": photo["original_size"]["height"],
            "text": item["slug"],
            "meta": meta,
        }
        if photo["caption"]:
            task["text"] = photo["caption"]
        return task


class GitHub(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in issue data from GitHub's API.
    Available settings: query, content_type, sort, order, page_size
    """

    source_name = "GitHub"
    url = "https://api.github.com/search/issues"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.content_type = settings.get("content_type", "title")
        self.params = {
            "q": settings.get("query", ""),
            "order": settings.get("order", "desc"),
            "sort": settings.get("sort", "created"),
            "per_page": settings.get("page_size", 100),
        }
        self.page = 0
        self.total_results = 0

    def __iter__(self):
        while True:
            self.params["page"] = self.page
            response = make_api_request(self.url, self.params)
            self.total_results = response["total_count"]
            stream = response["items"]
            for item in stream:
                task = self.get_task(item)
                if task is not None:
                    yield task
            self.page += 1

    def __len__(self):
        return self.total_results

    def get_task(self, item):
        text = item[self.content_type]
        if "pull_request" in item:
            return None
        meta = {"source": self.source_name, "url": item["html_url"]}
        return {"text": text, "priority": item["score"], "meta": meta}


class Unsplash(object):
    """DEPRECATED: Use custom loaders instead.
    Stream in photos for a search term from the Unsplash API.
    Available settings: query, page_size, image_size
    """

    source_name = "Unsplash"
    url = "https://api.unsplash.com/search/photos"

    def __init__(self, **settings):
        msg.warn(deprecation_msg)
        self.params = {
            "client_id": settings.get("key"),
            "query": settings.get("query", ""),
            "per_page": settings.get("page_size", 30),
        }
        self.image_size = settings.get("image_size", "small")
        self.page = 1
        self.total_results = 0

    def __iter__(self):
        while True:
            self.params["page"] = self.page
            log(f"LOADER: Making API request to {self.url}", self.params)
            response = make_api_request(self.url, self.params)
            self.total_results = response["total"]
            stream = response["results"]
            for item in stream:
                task = self.get_task(item)
                if task is not None:
                    yield task
            self.page += 1

    def __len__(self):
        return self.total_results

    def get_task(self, item):
        meta = {
            "source": self.source_name,
            "by": item["user"]["name"],
            "url": item["user"]["links"]["html"],
        }
        image = item["urls"][self.image_size]
        task = {"text": item["id"], "image": image, "meta": meta}
        width = image.split("&w=", 1)[1].split("&", 1)[0]
        if width.isdigit():
            width = int(width)
            height = item["height"] / item["width"] * width
            task["width"] = width
            task["height"] = height
        if item["description"] is not None:
            task["text"] = item["description"]
        return task


registry.apis.register("nyt", func=NewYorkTimes)
registry.apis.register("guardian", func=Guardian)
registry.apis.register("zeit", func=Zeit)
registry.apis.register("newsapi", func=NewsAPI)
registry.apis.register("twitter", func=Twitter)
registry.apis.register("tumblr", func=Tumblr)
registry.apis.register("github", func=GitHub)
registry.apis.register("unsplash", func=Unsplash)
