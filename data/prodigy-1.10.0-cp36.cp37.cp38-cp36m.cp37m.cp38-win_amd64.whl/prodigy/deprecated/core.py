from pathlib import Path

from ..util import split_string, get_labels

# fmt: off
recipe_args = {
    "dataset": ("Dataset ID", "positional", None, str),
    "spacy_model": ("Loadable spaCy model", "positional", None, str),
    "output_model": ("Directory to save trained model", "positional", None, Path),
    "output": ("Directory to save trained model", "option", "o", Path),
    "view": ("Annotation interface to use", "option", "v", str),
    "source": ("Source data (file path)", "positional", None, str),
    "source_file": ("File path or stdin", "positional", None, str),
    "label": ("Label to annotate", "option", "l", str),
    "label_set": ("Label(s) to annotate. Comma-separated list or path to text file with one label per line", "option", "l", get_labels),
    "entity_label": ("Label to annotate", "option", "l", split_string),
    "loader": ("Loader to use (if not set, loader is based on file extension)", "option", "lo", str),
    "api": ("DEPRECATED: API loader to use", "option", "a", str),
    "sortby": ("Sorting mechanism", "option", "sb", str),
    "batch_size": ("Batch size", "option", "b", int),
    "beam_width": ("Beam width", "option", "bw", int),
    "n_iter": ("Number of iterations", "option", "n", int),
    "dropout": ("Dropout rate", "option", "d", float),
    "factor": ("Portion of examples to train on", "option", "f", float),
    "exclude": ("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    "exclusive": ("Treat classes as mutually exclusive. If False, an example may have multiple correct classes.", "flag", "E"),
    "eval_id": ("ID of evaluation dataset", "option", "e", str),
    "eval_split": ("Portion of examples to split off for evaluation if no eval_id is provided", "option", "es", float),
    "n_samples": ("Number of samples", "option", "ns", int),
    "seeds": ("Seed terms dataset, path or comma-separated list", "option", "se", str),
    "silent": ("Don't print updates", "flag", "S", bool),
    "lang": ("ISO code of language to use if starting with a blank model", "option", "la", str),
    "patterns": ("Path to match patterns file", "option", "pt", Path),
    "output_file": ("Optional output file", "positional", None, str),
    "memorize": ("Enable answer cache and don't ask the same question twice", "flag", "M", bool),
    "whole_text": ("Make accept/reject refer to whole text (not single span)", "flag", "W", bool),
    "unsegmented": ("Don't split sentences", "flag", "U", bool),
    "no_missing": ("Assume all correct spans are in the gold annotation, and any spans not in the gold annotation are incorrect.", "flag", "NM", bool),
    "tag_map": ("Path to JSON mapping table for POS tags. Read from the spaCy tagger model if not provided. See https://spacy.io/usage/adding-languages#tag-map", "option", "tm", Path),
    "init_tok2vec": ("Path to pretrained weights for the token-to-vector parts of the model. See 'spacy pretrain'. Experimental.", "option", "t2v", Path),
}
# fmt: on
