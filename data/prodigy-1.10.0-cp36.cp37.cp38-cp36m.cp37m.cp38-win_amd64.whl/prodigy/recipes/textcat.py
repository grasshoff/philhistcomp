from typing import List, Optional, Dict, Any, Union, Iterable
from pathlib import Path
import spacy

from ..models.matcher import PatternMatcher
from ..models.textcat import TextClassifier
from ..components.loaders import get_stream
from ..components.preprocess import add_label_options, add_labels_to_stream
from ..components.sorters import prefer_uncertain
from ..core import recipe
from ..util import combine_models, log, msg, get_labels, split_string

# Restore deprecated recipes
from ..deprecated.train import textcat_batch_train as batch_train  # noqa: F401
from ..deprecated.train import textcat_train_curve as train_curve  # noqa: F401


@recipe(
    "textcat.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    long_text=("DEPRECATED: Use long-text mode", "flag", "L", bool),
    init_tok2vec=("Path to pretrained weights for the token-to-vector parts of the model. See 'spacy pretrain'.", "option", "t2v", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    init_tok2vec: Optional[Union[str, Path]] = None,
    loader: Optional[str] = None,
    long_text: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Collect the best possible training data for a text classification model
    with the model in the loop. Based on your annotations, Prodigy will decide
    which questions to ask next.
    """
    log("RECIPE: Starting recipe textcat.teach", locals())
    if label is None:
        msg.fail("textcat.teach requires at least one --label", exits=1)
    if spacy_model.startswith("blank:"):
        nlp = spacy.blank(spacy_model.replace("blank:", ""))
    else:
        nlp = spacy.load(spacy_model)
    log(f"RECIPE: Creating TextClassifier with model {spacy_model}")
    model = TextClassifier(nlp, label, long_text=long_text, init_tok2vec=init_tok2vec)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if patterns is None:
        predict = model
        update = model.update
    else:
        matcher = PatternMatcher(
            model.nlp,
            prior_correct=5.0,
            prior_incorrect=5.0,
            label_span=False,
            label_task=True,
            filter_labels=label,
            combine_matches=True,
            task_hash_keys=("label",),
        )
        matcher = matcher.from_disk(patterns)
        log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
        # Combine the textcat model with the PatternMatcher to annotate both
        # match results and predictions, and update both models.
        predict, update = combine_models(model, matcher)
    stream = prefer_uncertain(predict(stream))
    return {
        "view_id": "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "update": update,
        "config": {"lang": nlp.lang, "labels": model.labels},
    }


@recipe(
    "textcat.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclusive=("Treat classes as mutually exclusive (if not set, an example can have multiple correct classes)", "flag", "E", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def manual(
    dataset: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclusive: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Manually annotate categories that apply to a text. If more than one label
    is specified, categories are added as multiple choice options. If the
    --exclusive flag is set, categories become mutually exclusive, meaning that
    only one can be selected during annotation.
    """
    log("RECIPE: Starting recipe textcat.manual", locals())
    labels = label
    if not labels:
        msg.fail("textcat.manual requires at least one --label", exits=1)
    has_options = len(labels) > 1
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if has_options:
        stream = add_label_options(stream, label)
    else:
        stream = add_labels_to_stream(stream, label)

    return {
        "view_id": "choice" if has_options else "classification",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "labels": labels,
            "choice_style": "single" if exclusive else "multiple",
            "exclude_by": "input" if has_options else "task",
            "force_stream_order": True,
        },
    }
