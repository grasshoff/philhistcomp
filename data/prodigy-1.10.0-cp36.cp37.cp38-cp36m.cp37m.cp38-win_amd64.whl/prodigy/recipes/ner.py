from typing import List, Optional, Union, Iterable, Dict, Any
import murmurhash
import spacy
import copy

from .compare import get_questions as get_compare_questions
from .compare import get_printer as get_compare_printer
from ..models.ner import EntityRecognizer
from ..models.matcher import PatternMatcher
from ..components.db import connect
from ..components.preprocess import split_sentences, add_tokens
from ..components.sorters import prefer_uncertain
from ..components.loaders import get_stream
from ..core import recipe
from ..util import combine_models, set_hashes, log, split_string, get_labels
from ..util import INPUT_HASH_ATTR, TASK_HASH_ATTR, msg

# Restore deprecated recipes
from ..deprecated.train import ner_batch_train as batch_train  # noqa: F401
from ..deprecated.train import ner_train_curve as train_curve  # noqa: F401


def get_labels_from_ner(nlp, pipe_name: str = "ner") -> List[str]:
    """Get the labels (e.g. "PERSON") of a spaCy NER pipeline component.

    nlp (spacy.language.Language): The nlp object.
    pipe_name (unicode): Name of the NER pipeline component (default: 'ner').
    RETURNS (list): The available unique labels, sorted alphabetically.
    """
    if pipe_name not in nlp.pipe_names:
        return []
    ner = nlp.get_pipe(pipe_name)
    return list(ner.labels)


def remove_tokens(answers):
    """Remove token information from example before they're placed in the
    database. Used if character highlighting is enabled."""
    for eg in answers:
        del eg["tokens"]
        if "spans" in eg:
            for span in eg["spans"]:
                del span["token_start"]
                del span["token_end"]
    return answers


@recipe(
    "ner.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with an entity recognizer", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> Dict[str, Any]:
    """
    Collect the best possible training data for a named entity recognition
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe ner.teach", locals())
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    nlp = spacy.load(spacy_model)
    log(f"RECIPE: Creating EntityRecognizer using model {spacy_model}")
    model = EntityRecognizer(nlp, label=label)
    if label is not None and patterns is None:
        log("RECIPE: Making sure all labels are in the model", label)
        for l in label:
            if not model.has_label(l):
                msg.fail(
                    f"Can't find label '{l}' in model {spacy_model}",
                    "ner.teach will only show entities with one of the "
                    "specified labels. If a label is not available in the "
                    "model, Prodigy won't be able to propose entities for "
                    "annotation. To add a new label, you can specify a "
                    "patterns file containing examples of the new entity "
                    "as the --patterns argument or pre-train your model "
                    "with examples of the new entity and load it back in.",
                    exits=1,
                )
    if patterns is None:
        predict = model
        update = model.update
    else:
        matcher = PatternMatcher(model.nlp).from_disk(patterns)
        log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
        # Combine the NER model with the PatternMatcher to annotate both
        # match results and predictions, and update both models.
        predict, update = combine_models(model, matcher)
    if not unsegmented:
        stream = split_sentences(model.orig_nlp, stream)
    stream = prefer_uncertain(predict(stream))

    return {
        "view_id": "ner",
        "dataset": dataset,
        "stream": stream,
        "update": update,
        "exclude": exclude,
        "config": {
            "lang": model.nlp.lang,
            "label": ", ".join(label) if label is not None else "all",
        },
    }


@recipe(
    "ner.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model for tokenization or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    highlight_chars=("Allow highlighting individual characters instead of tokens", "flag", "C", bool),
    # fmt: on
)
def manual(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    exclude: Optional[List[str]] = None,
    highlight_chars: bool = False,
) -> Dict[str, Any]:
    """
    Mark spans by token. Requires only a tokenizer and no entity recognizer,
    and doesn't do any active learning. If patterns are provided, their matches
    are highlighted in the example, if available. The recipe will present
    all examples in order, so even examples without matches are shown. If
    character highlighting is enabled, no "tokens" are saved to the database.
    """
    log("RECIPE: Starting recipe ner.manual", locals())
    if spacy_model.startswith("blank:"):
        nlp = spacy.blank(spacy_model.replace("blank:", ""))
    else:
        nlp = spacy.load(spacy_model)
    labels = label  # comma-separated list or path to text file
    if not labels:
        labels = get_labels_from_ner(nlp)
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if patterns is not None:
        pattern_matcher = PatternMatcher(nlp, combine_matches=True, all_examples=True)
        pattern_matcher = pattern_matcher.from_disk(patterns)
        stream = (eg for _, eg in pattern_matcher(stream))
    # Add "tokens" key to the tasks, either with words or characters
    stream = add_tokens(nlp, stream, use_chars=highlight_chars)

    return {
        "view_id": "ner_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "before_db": remove_tokens if highlight_chars else None,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "ner_manual_highlight_chars": highlight_chars,
            "force_stream_order": True,
        },
    }


@recipe(
    "ner.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with an entity recognizer", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def make_gold(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> Dict[str, Any]:
    """
    Create gold data for NER by correcting a model's suggestions.
    """
    log("RECIPE: Starting recipe ner.correct (previously ner.make-gold)", locals())
    nlp = spacy.load(spacy_model)
    labels = label  # comma-separated list or path to text file
    if not labels:
        labels = get_labels_from_ner(nlp)
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if not unsegmented:
        stream = split_sentences(nlp, stream)
    stream = add_tokens(nlp, stream)

    def make_tasks(nlp, stream: Iterable[dict]) -> Iterable[dict]:
        """Add a 'spans' key to each example, with predicted entities."""
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True):
            task = copy.deepcopy(eg)
            spans = []
            for ent in doc.ents:
                if labels and ent.label_ not in labels:
                    continue
                spans.append(
                    {
                        "token_start": ent.start,
                        "token_end": ent.end - 1,
                        "start": ent.start_char,
                        "end": ent.end_char,
                        "text": ent.text,
                        "label": ent.label_,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = spans
            task = set_hashes(task)
            yield task

    stream = make_tasks(nlp, stream)

    return {
        "view_id": "ner_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "force_stream_order": True,
        },
    }


# Set alias for old deprecated name
recipe("ner.make-gold", **make_gold.__annotations__)(make_gold)


@recipe(
    "ner.silver-to-gold",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    silver_sets=("Comma-separated datasets to convert", "positional", None, split_string),
    spacy_model=("Loadable spaCy model with an entity recognizer", "positional", None, str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    # fmt: on
)
def silver_to_gold(
    dataset: str,
    silver_sets: List[str],
    spacy_model: str,
    label: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Take existing "silver" datasets with binary accept/reject annotations,
    merge the annotations to find the best possible analysis given the
    constraints defined in the annotations, and manually edit it to create
    a perfect and complete "gold" dataset.
    """

    def filter_stream(stream: Iterable[dict]) -> Iterable[dict]:
        # make_best uses all labels in the model, so we need to filter by label here
        for eg in stream:
            eg["spans"] = [s for s in eg.get("spans", []) if s["label"] in labels]
            yield eg

    log("RECIPE: Starting recipe ner.silver-to-gold", locals())
    DB = connect()
    data = []
    for set_id in silver_sets:
        if set_id not in DB:
            msg.fail(f"Can't find input dataset '{set_id}' in database", exits=1)
        examples = DB.get_dataset(set_id)
        data += examples
    log(f"RECIPE: Loaded {len(data)} examples from {len(silver_sets)} dataset(s)")
    nlp = spacy.load(spacy_model)
    labels = label
    if not labels:
        labels = get_labels_from_ner(nlp)
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    # Initialize Prodigy's entity recognizer model, which uses beam search to
    # find all possible analyses and outputs (score, example) tuples,
    # then merge all annotations and find the best possible analyses
    model = EntityRecognizer(nlp, label=labels)
    stream = model.make_best(data)
    stream = filter_stream(stream)
    stream = add_tokens(nlp, stream)  # add "tokens" for faster annotation

    return {
        "dataset": dataset,
        "view_id": "ner_manual",
        "stream": stream,
        "config": {"lang": nlp.lang, "labels": labels},
    }


@recipe(
    "ner.eval-ab",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    before_model=("Loadable spaCy model with an entity recognizer", "positional", None, str),
    after_model=("Loadable spaCy model with an entity recognizer", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def ab_evaluate(
    dataset: str,
    before_model: str,
    after_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> Dict[str, Any]:
    """
    Evaluate a n NER model and build an evaluation set from a stream.
    """
    log("RECIPE: Starting recipe ner.eval-ab", locals())

    def get_tasks(model, stream: Iterable[dict], name: str) -> Iterable[dict]:
        tuples = ((eg["text"], eg) for eg in stream)
        for i, (doc, eg) in enumerate(model.nlp.pipe(tuples, as_tuples=True)):
            spans = []
            for ent in doc.ents:
                label = ent.label_
                if not model.labels or label in model.labels:
                    start = ent.start_char
                    end = ent.end_char
                    spans.append({"start": start, "end": end, "label": label})
            task = {
                "id": i,
                "input": {"text": eg["text"]},
                "output": {"text": eg["text"], "spans": spans},
            }
            task[INPUT_HASH_ATTR] = murmurhash.hash(name + str(i))
            task[TASK_HASH_ATTR] = murmurhash.hash(name + str(i))
            yield task

    before_model = EntityRecognizer(spacy.load(before_model), label=label)
    after_model = EntityRecognizer(spacy.load(after_model), label=label)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    stream = list(stream)
    if not unsegmented:
        stream = list(split_sentences(before_model.nlp, stream))
    before_stream = list(get_tasks(before_model, stream, "before"))
    after_stream = list(get_tasks(after_model, stream, "after"))
    stream = list(get_compare_questions(before_stream, after_stream, True))
    on_exit = get_compare_printer("Before", "After")

    return {
        "view_id": "choice",
        "dataset": dataset,
        "stream": stream,
        "on_exit": on_exit,
        "exclude": exclude,
        "config": {"force_stream_order": True},
    }
