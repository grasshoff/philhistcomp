from typing import List, Optional, Union, Iterable, Dict, Any

from ..core import recipe
from ..util import split_string
from .rel import manual as rel_manual


@recipe(
    "coref.manual",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Label(s) to use for coreference relation", "option", "l", split_string),
    pos_tags=("List of coarse-grained POS tags to enable for annotation", "option", "ps", split_string),
    poss_pron_tags=("List of fine-grained tag values for possessive pronoun to use in patterns", "option", "pp", split_string),
    ner_labels=("List of NER labels to use if model has entity recognizer", "option", "nl", split_string),
    show_arrow_heads=("Show the arrow heads visually", "option", "SA", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string)
    # fmt: on
)
def manual(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: List[str] = ["COREF"],
    exclude: Optional[List[str]] = None,
    pos_tags: List[str] = ["NOUN", "PROPN", "PRON", "DET"],
    poss_pron_tags: List[str] = ["PRP$"],
    ner_labels: List[str] = ["PERSON", "ORG"],
    show_arrow_heads: bool = False,
) -> Dict[str, Any]:
    """Create training data for coreference resolution. Coreference resolution
    is the challenge of linking ambiguous mentions such as "her" or "that woman"
    back to an antecedent providing more context about the entity in question.

    This recipe allows you to focus on nouns, proper nouns and pronouns
    specifically, by disabling all other tokens. You can customize the labels
    used to extract those using the recipe arguments.
    """
    NP_LABEL = "NP"
    patterns = [
        {
            "label": NP_LABEL,
            "pattern": [
                {"POS": "DET", "TAG": {"NOT_IN": poss_pron_tags}, "OP": "?"},
                {"POS": "ADJ", "OP": "*"},
                # Proper nouns but no entities, otherwise this custom pattern
                # would overwrite them
                {
                    "POS": {"IN": ["PROPN", "NOUN"]},
                    "OP": "+",
                    "ENT_TYPE": {"NOT_IN": ner_labels},
                },
            ],
        }
    ]
    disable_patterns = [
        # Other POS tags but no tokens in our previously matched NPs
        [{"POS": {"NOT_IN": pos_tags}, "_": {"label": {"NOT_IN": [NP_LABEL]}}}]
    ]
    disable_patterns = [{"pattern": pat} for pat in disable_patterns]
    components = rel_manual(
        dataset,
        spacy_model,
        source,
        loader,
        label=label,
        exclude=exclude,
        patterns=patterns,
        disable_patterns=disable_patterns,
        add_ents=True,
        add_nps=False,
        wrap=True,
        hide_arrow_heads=not show_arrow_heads,
    )
    return components
