from typing import List, Optional, Union, Iterable, Dict, Any
import spacy
import copy
from pathlib import Path
import srsly

from ..models.pos import Tagger
from ..components.loaders import get_stream
from ..components.preprocess import split_sentences, add_tokens
from ..components.sorters import prefer_uncertain
from ..core import recipe
from ..util import log, set_hashes, msg, split_string, get_labels, INPUT_HASH_ATTR

# Restore deprecated recipes
from ..deprecated.train import pos_batch_train as batch_train  # noqa: F401
from ..deprecated.train import pos_train_curve as train_curve  # noqa: F401


# fmt: off
POS_TAGS = ["ADJ", "ADP", "ADV", "AUX", "CONJ", "CCONJ", "DET", "INTJ", "NOUN",
            "NUM", "PART", "PRON", "PROPN", "PUNCT", "SCONJ", "SYM", "VERB",
            "X", "SPACE"]
# fmt: on


def get_tag_map(tag_map: Union[str, Path]) -> dict:
    log("RECIPE: Using tag map from file", tag_map)
    if not Path(tag_map).exists():
        msg.fail("Not a valid tag map file", tag_map, exits=1)
    tag_map = srsly.read_json(tag_map)
    return tag_map


@recipe(
    "pos.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with a tagger", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    tag_map=("Path to JSON mapping table for POS tags. Read from the model if not provided", "option", "tm", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    tag_map: Optional[Union[str, Path]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> Dict[str, Any]:
    """
    Collect the best possible training data for a part-of-speech tagging
    model with the model in the loop. Based on your annotations, Prodigy will
    decide which questions to ask next.
    """
    log("RECIPE: Starting recipe pos.teach", locals())
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    log(f"RECIPE: Creating Tagger using model {spacy_model}")
    labels = label or POS_TAGS
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    if tag_map is not None:
        tag_map = get_tag_map(tag_map)
    model = Tagger(spacy.load(spacy_model), label=labels, tag_map=tag_map)
    if not unsegmented:
        stream = split_sentences(model.nlp, stream)
    stream = add_tokens(model.nlp, stream)  # add tokens for faster annotation
    stream = prefer_uncertain(model(stream), algorithm="probability")

    return {
        "view_id": "pos",
        "dataset": dataset,
        "stream": stream,
        "update": model.update,
        "exclude": exclude,
        "config": {
            "lang": model.nlp.lang,
            "label": ", ".join(labels) if label is not None else "all",
        },
    }


@recipe(
    "pos.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with a tagger", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    fine_grained=("Use fine-grained tags, i.e. Token.tag_ instead of Token.pos_", "flag", "FG", bool),
    # fmt: on,
)
def make_gold(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
    fine_grained: bool = False,
) -> Dict[str, Any]:
    """
    Create gold data for part-of-speech tags by correcting a model's
    predictions.

    The --fine-grained flag enables fine-grained part-of-speech tags, i.e.
    Token.tag_ instead of Token.pos_. Warning: Can lead to unexpected results
    and very long tags for some language models that use fine-grained tags with
    morphological features.
    """
    log("RECIPE: Starting recipe pos.correct (previously pos.make-gold)", locals())
    nlp = spacy.load(spacy_model)
    log(f"RECIPE: Loaded model {spacy_model}")
    labels = label  # comma-separated list of path to text file
    if not labels and not fine_grained:
        msg.info(f"Using universal coarse-grained POS tags: {', '.join(POS_TAGS)}")
        labels = POS_TAGS
    elif not labels:
        msg.fail("pos.teach with fine-grained tags needs at least one --label", exits=1)
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    if not unsegmented:
        stream = split_sentences(nlp, stream)
    stream = add_tokens(nlp, stream)  # add tokens for faster annotation

    def make_tasks(nlp, stream: Iterable[dict]) -> Iterable[dict]:
        """Add a 'spans' key to each example, with predicted tags."""
        texts = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(texts, as_tuples=True):
            task = copy.deepcopy(eg)
            spans = []
            for i, token in enumerate(doc):
                pos_tag = token.pos_ if not fine_grained else token.tag_
                if labels and pos_tag not in labels:
                    continue
                spans.append(
                    {
                        "token_start": i,
                        "token_end": i,
                        "start": token.idx,
                        "end": token.idx + len(token.text),
                        "text": token.text,
                        "label": pos_tag,
                        "source": spacy_model,
                        "input_hash": eg[INPUT_HASH_ATTR],
                    }
                )
            task["spans"] = spans
            task = set_hashes(task)
            yield task

    stream = make_tasks(nlp, stream)

    return {
        "view_id": "pos_manual",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {
            "lang": nlp.lang,
            "labels": labels,
            "exclude_by": "input",
            "force_stream_order": True,
        },
    }


# Set alias for old deprecated name
recipe("pos.make-gold", **make_gold.__annotations__)(make_gold)
