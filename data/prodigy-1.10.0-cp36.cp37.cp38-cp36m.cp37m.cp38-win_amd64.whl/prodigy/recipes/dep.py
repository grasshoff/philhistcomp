from typing import List, Optional, Union, Iterable, Dict, Any
import copy
import spacy
from spacy.syntax import nonproj
from spacy.tokens import Doc
from spacy.gold import GoldParse

from ..models.dep import DependencyParser
from ..components.preprocess import split_sentences, add_tokens, get_token
from ..components.sorters import prefer_uncertain
from ..components.loaders import get_stream
from ..core import recipe
from ..util import log, get_labels, split_string, msg

# Restore deprecated recipes
from ..deprecated.train import dep_batch_train as batch_train  # noqa: F401
from ..deprecated.train import dep_train_curve as train_curve  # noqa: F401


@recipe(
    "dep.teach",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with a parser", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    # fmt: on
)
def teach(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    exclude: Optional[List[str]] = None,
    unsegmented: bool = False,
) -> Dict[str, Any]:
    """
    Collect the best possible training data for a dependency parsing model with
    the model in the loop. Based on your annotations, Prodigy will decide which
    questions to ask next.
    """
    log("RECIPE: Starting recipe dep.teach", locals())
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    nlp = spacy.load(spacy_model, disable=["ner", "tagger"])
    log(f"RECIPE: Creating DependencyParser using model {spacy_model}")
    model = DependencyParser(nlp, label=label)
    if not unsegmented:
        stream = split_sentences(model.orig_nlp, stream)
    stream = add_tokens(model.orig_nlp, stream)  # add tokens for faster annotation
    stream = prefer_uncertain(model(stream))

    return {
        "view_id": "dep",
        "dataset": dataset,
        "stream": stream,
        "update": model.update,
        "exclude": exclude,
        "config": {"lang": model.nlp.lang},
    }


@recipe(
    "dep.correct",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model with a dependency parser", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    update=("Whether to update the model during annotation", "flag", "UP", bool),
    wrap=("Wrap lines in the UI by default (instead of showing tokens in one row)", "flag", "W", bool),
    unsegmented=("Don't split sentences", "flag", "U", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def correct(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    update: bool = False,
    wrap: bool = False,
    unsegmented: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Create gold data for dependency parsing by correcting a model's suggestions.
    """
    log("RECIPE: Starting recipe dep.correct", locals())
    stream = get_stream(source, None, loader, rehash=True, dedup=True, input_key="text")
    nlp = spacy.load(spacy_model)
    if "parser" not in nlp.pipe_names:
        msg.warn(f"No 'parser' component found in pipeline of model '{spacy_model}'")
    labels = get_dep_labels(nlp, label)
    log(f"RECIPE: Annotating with {len(labels)} labels", labels)

    def preprocess_stream(stream, nlp):
        data_tuples = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(data_tuples, as_tuples=True):
            sents = [doc[: len(doc) - 1]] if unsegmented else doc.sents
            for sent in sents:
                eg = copy.deepcopy(eg)
                tokens = []
                relations = []
                hidden_relations = []
                for token in sent:
                    t_obj = get_token(token)
                    if not unsegmented:
                        # Adjust token boundaries to sentences
                        t_obj["start"] = t_obj["start"] - sent.start_char
                        t_obj["end"] = t_obj["end"] - sent.start_char  # Not an error
                    tokens.append(t_obj)
                    rel = {"child": token.i, "head": token.head.i, "label": token.dep_}
                    if labels is None or token.dep_ in labels:
                        relations.append(rel)
                    else:
                        hidden_relations.append(rel)
                eg["tokens"] = tokens
                eg["relations"] = relations
                # We need to save the extra relations, even if we don't display them,
                # so that we can recover the full parse later.
                eg["hidden_relations"] = hidden_relations
                # If the data has existing "spans", we need to remove them – otherwise
                # they will be merged in the relations UI
                if "spans" in eg:
                    del eg["spans"]
                yield eg

    def make_update(batch):
        docs = []
        golds = []
        for eg in batch:
            # Check for conflicts in the parse tree. The annotations may not
            # resolve to a valid parse. If not, don't update.
            if not _is_valid_parse(eg):
                continue
            if eg["answer"] != "accept":
                continue
            doc, gold = _make_gold(nlp, eg)
            docs.append(doc)
            golds.append(gold)
        nlp.update(docs, golds)

    def validate_answer(answer):
        # Don't allow parse annotations with multiple roots, if roots are
        # annotated
        roots = [rel["label"] for rel in answer["relations"] if rel["label"] == "ROOT"]
        if len(roots) != 1:
            err = f"A valid dependency parse needs to contain exactly one root (found {len(roots)})"
            raise ValueError(err)

    stream = preprocess_stream(stream, nlp)

    return {
        "view_id": "relations",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "update": make_update if update else None,
        "validate_answer": validate_answer if "ROOT" in labels else None,
        "config": {
            "lang": nlp.lang,
            "exclude_by": "input",
            "labels": labels,
            "wrap_relations": wrap,
            "custom_theme": {"cardMaxWidth": "90%", "relationHeight": 150},
            "force_stream_order": True,
        },
    }


def get_dep_labels(nlp, labels, pipe_name="parser") -> List[str]:
    """Get the labels for dependency annotation, either based on the --labels
    provided on the command line, or the spaCy parser pipeline component.

    nlp (spacy.language.Language): The nlp object.
    labels (list): The value of --labels provided by the user.
    pipe_name (str): Name of the NER pipeline component (default: 'ner').
    RETURNS (list): The available labels.
    """
    if not labels:
        if pipe_name not in nlp.pipe_names:
            return []
        parser = nlp.get_pipe(pipe_name)
        labels = list(parser.labels)
        if not labels:
            msg.fail("No --label argument set and no labels found in model", exits=1)
        msg.text(f"Using {len(labels)} labels from model: {', '.join(labels)}")
    if "ROOT" not in labels:
        if "root" in labels:
            labels[labels.index("root")] = "ROOT"
        else:
            msg.warn("Not annotating with a 'ROOT' label")
    return labels


def _make_gold(nlp, eg):
    words = [token["text"] for token in eg["tokens"]]
    deps = [None] * len(words)
    heads = [None] * len(words)
    for rel in eg["hidden_relations"] + eg["relations"]:
        deps[rel["child"]] = rel["label"]
        heads[rel["head"]] = rel["head"]
    doc = Doc(nlp.vocab, words=words)
    gold = GoldParse(doc, words=words, heads=heads, deps=deps)
    return doc, gold


def _is_valid_parse(eg):
    """Check for multiple heads and cycles."""
    seen = set()
    heads = {}
    relations = eg.get("relations", [])
    for rel in relations:
        if rel["child"] in seen:
            return False
        seen.add(rel["child"])
        heads[rel["child"]] = rel["head"]
    try:
        if nonproj.contains_cycle(heads):
            return False
    except KeyError:
        return False
    return True
