from typing import List, Optional, Union, Iterable, Dict, Any
from collections import Counter
import spacy

from ..components import printers
from ..components.loaders import get_stream
from ..components.db import connect
from ..models.matcher import PatternMatcher
from ..core import recipe
from ..util import log, msg, color, get_labels, split_string, VIEW_ID_ATTR


@recipe(
    "mark",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    view_id=("Annotation interface to use", "option", "v", str),
    memorize=("DEPRECATED: Covered by auto-exclude current dataset", "flag", "M", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt :on
)
def mark(
    dataset: str,
    source: Union[str, Iterable[dict]],
    view_id: Optional[str] = None,
    label: Optional[List[str]] = None,
    loader: Optional[str] = None,
    memorize: bool = False,
    exclude: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Click through pre-prepared examples, with no model in the loop.
    """
    log("RECIPE: Starting recipe mark", locals())
    if view_id is None:
        msg.fail("The --view-id argument (annotation UI to use) is required", exits=1)
    stream = get_stream(source, loader=loader)

    def ask_questions(stream: Iterable[dict]) -> Iterable[dict]:
        for eg in stream:
            if label:
                eg["label"] = label[0]
            yield eg

    def print_results(ctrl):
        examples = ctrl.db.get_dataset(ctrl.session_id)
        if examples:
            counts = Counter()
            for eg in examples:
                counts[eg["answer"]] += 1
            for key in ["accept", "reject", "ignore"]:
                if key in counts:
                    msg.row([key.title(), color(round(counts[key]), key)], widths=10)

    # Add label or label set to config if available
    config = {"force_stream_order": True}
    if label and len(label) == 1:
        config["label"] = label[0]
    elif label and len(label) > 1:
        config["labels"] = label

    return {
        "view_id": view_id,
        "dataset": dataset,
        "stream": ask_questions(stream),
        "exclude": exclude,
        "on_exit": print_results,
        "config": config,
    }


@recipe(
    "match",
    # fmt: off
    dataset=("Dataset to save annotations to", "positional", None, str),
    spacy_model=("Loadable spaCy model or blank:lang (e.g. blank:en)", "positional", None, str),
    source=("Data to annotate (file path or '-' to read from standard input)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
    label=("Comma-separated label(s) to annotate or text file with one label per line", "option", "l", get_labels),
    patterns=("Path to match patterns file", "option", "pt", str),
    label_task=("Assign the matched label to the task", "flag", "LT", bool),
    label_span=("Assign the matched label to the matched span", "flag", "LS", bool),
    combine_matches=("Combine all matches and only show an example once", "flag", "C", bool),
    exclude=("Comma-separated list of dataset IDs whose annotations to exclude", "option", "e", split_string),
    # fmt: on
)
def match(
    dataset: str,
    spacy_model: str,
    source: Union[str, Iterable[dict]],
    loader: Optional[str] = None,
    label: Optional[List[str]] = None,
    patterns: Optional[str] = None,
    label_task: bool = False,
    label_span: bool = False,
    combine_matches: bool = False,
    exclude: Optional[List[str]] = None,
):
    log("RECIPE: Starting recipe match", locals())
    if label is None:
        msg.fail("match requires at least one --label", exits=1)
    if patterns is None:
        msg.fail("match requires a --patterns file", exits=1)
    if spacy_model.startswith("blank:"):
        nlp = spacy.blank(spacy_model.replace("blank:", ""))
    else:
        nlp = spacy.load(spacy_model)
    matcher = PatternMatcher(
        nlp,
        label_span=label_span,
        label_task=label_task,
        filter_labels=label,
        combine_matches=combine_matches,
        task_hash_keys=("label",),
    )
    matcher = matcher.from_disk(patterns)
    log("RECIPE: Created PatternMatcher and loaded in patterns", patterns)
    stream = get_stream(
        source, loader=loader, rehash=True, dedup=True, input_key="text"
    )
    stream = (eg for score, eg in matcher(stream))
    return {
        "view_id": "classification" if label_task else "ner",
        "dataset": dataset,
        "stream": stream,
        "exclude": exclude,
        "config": {"lang": nlp.lang, "force_stream_order": True},
    }


@recipe(
    "print-dataset",
    dataset=("Dataset to print", "positional", None, str),
    style=("Annotation type", "option", "s", str, ["auto", "text", "textcat", "spans"]),
)
def print_dataset(dataset: str, style: str = "auto"):
    """
    Pretty-print annotations from a given dataset on the command line. Supports
    plain text, text classification and NER annotations. If no `--type` is
    specified, Prodigy will try to infer it from the data via the `"_view_id"`
    that's automatically added since v1.8.
    """
    log("RECIPE: Starting recipe print-dataset", locals())
    # fmt: off
    spans_ids = ["ner", "ner_manual", "spans", "spans_manual", "pos", "pos_manual"]
    textcat_ids = ["classification", "choice"]
    text_ids = ["text"]
    # fmt: on
    DB = connect()
    if dataset not in DB:
        msg.fail(f"Can't find dataset '{dataset}'", exits=1)
    examples = DB.get_dataset(dataset)
    if not examples:
        msg.fail(f"Can't load '{dataset}' from database {DB.db_name}", exits=1)
    if style == "auto":
        log("RECIPE: Getting output style and view ID based on first example")
        view_id = examples[0].get(VIEW_ID_ATTR)
        if not view_id:
            err = "Use the --style option to set text, spans or textcat"
            msg.fail("No view ID found in data", err, exits=1)
        elif view_id in textcat_ids:
            style = "textcat"
        elif view_id in spans_ids:
            style = "spans"
        elif view_id in text_ids:
            style = "text"
        else:
            supported = f"Supported: {','.join(spans_ids + textcat_ids + text_ids)}"
            msg.fail(f"Unsupported view ID: '{view_id}'", supported, exits=1)
    printers.pretty_print(examples, views=[style])


@recipe(
    "print-stream",
    spacy_model=("Loadable spaCy model", "positional", None, str),
    source=("Source data (file path)", "positional", None, str),
    loader=("Loader (guessed from file extension if not set)", "option", "lo", str),
)
def print_stream(
    spacy_model: str, source: Union[str, Iterable[dict]], loader: Optional[str] = None,
):
    """
    Pretty-print the model's predictions on the command line. Supports named
    entities and text categories and will display the annotations if the model
    components are available. For textcat annotations, only the category with the
    highest score is shown if the score is greater than 0.5.
    """
    log("RECIPE: Starting recipe print-stream", locals())

    def make_examples(
        stream: Iterable[dict], nlp: spacy.language.Language
    ) -> Iterable[dict]:
        data_tuples = ((eg["text"], eg) for eg in stream)
        for doc, eg in nlp.pipe(data_tuples, as_tuples=True):
            eg["spans"] = [
                {"start": e.start_char, "end": e.end_char, "label": e.label_}
                for e in doc.ents
            ]
            if doc.cats:
                max_cat = max(doc.cats, key=doc.cats.get)
                eg["label"] = max_cat if doc.cats[max_cat] > 0.5 else "none"
            yield eg

    nlp = spacy.load(spacy_model)
    views = []
    if "ner" in nlp.pipe_names:
        views.append("spans")
    if "textcat" in nlp.pipe_names:
        views.append("textcat")
    log(f"RECIPE: Pretty-printing for views {views}")
    stream = get_stream(source, loader=loader, rehash=True, input_key="text")
    stream = make_examples(stream, nlp)
    printers.pretty_print(stream, views=views)
