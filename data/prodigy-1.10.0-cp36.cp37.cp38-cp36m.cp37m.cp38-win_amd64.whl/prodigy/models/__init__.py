from .ner import EntityRecognizer, merge_spans  # noqa: F401
from .dep import DependencyParser, merge_arcs  # noqa: F401
from .pos import Tagger, merge_tags  # noqa: F401


class AnnotationModels:
    EntityRecognizer = EntityRecognizer
    DependencyParser = DependencyParser
    Tagger = Tagger
